const apiKey = "6a1fd059bf37d679588a16c75e98acb3"; // ضع مفتاح GNews API الخاص بك هنا
const newsContainer = document.getElementById("newsContainer");
const categorySelect = document.getElementById("categorySelect");
const cacheKey = "cachedNews";
const cacheExpiryKey = "newsCacheExpiry";
const cacheDuration = 2 * 60 * 60 * 1000; // ساعتين

// التحقق من وجود بيانات مخزنة محليًا
function loadCachedNews() {
    const cachedData = localStorage.getItem(cacheKey);
    const cacheExpiry = localStorage.getItem(cacheExpiryKey);
    const now = new Date().getTime();

    if (cachedData && cacheExpiry && now < parseInt(cacheExpiry)) {
        console.log("تحميل الأخبار من التخزين المحلي");
        displayNews(JSON.parse(cachedData));
    } else {
        fetchNews();
    }
}

// جلب الأخبار من GNews API
function fetchNews() {
    const category = categorySelect.value;
    const apiUrl = `https://gnews.io/api/v4/top-headlines?token=${apiKey}&lang=ar&country=ae&topic=${category}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.articles) {
                localStorage.setItem(cacheKey, JSON.stringify(data.articles));
                localStorage.setItem(cacheExpiryKey, (new Date().getTime() + cacheDuration).toString());
                console.log("تم تحديث الأخبار من API");
                displayNews(data.articles);
            } else {
                newsContainer.innerHTML = "<p>لا توجد أخبار متاحة.</p>";
            }
        })
        .catch(error => {
            console.error("خطأ في جلب الأخبار:", error);
            newsContainer.innerHTML = "<p>حدث خطأ أثناء تحميل الأخبار.</p>";
        });
}

// عرض الأخبار في الصفحة
function displayNews(articles) {
    newsContainer.innerHTML = "";

    if (articles.length === 0) {
        newsContainer.innerHTML = "<p>لا توجد أخبار متاحة.</p>";
        return;
    }

    articles.forEach(article => {
        const newsItem = document.createElement("div");
        newsItem.className = "news-item";

        newsItem.innerHTML = `
            <img src="${article.image || 'placeholder.jpg'}" alt="صورة الخبر">
            <h2>${article.title}</h2>
            <p>${article.description || "لا يوجد وصف متاح"}</p>
            <a href="${article.url}" target="_blank">اقرأ المزيد</a>
        `;

        newsContainer.appendChild(newsItem);
    });
}

// تحميل الأخبار عند فتح التطبيق
loadCachedNews();
